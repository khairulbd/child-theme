<?php get_header();?>
<body <?php body_class();?>>
<?php get_template_part('hero');?>

<div class="posts <?php post_class();?>">
<?php while(have_posts()) : the_post();?>
    <div class="post">
        <div class="container">
            <div class="row">
                 <div class="col-md-10 offset-md-1 text-center">
                    <h2><?php the_title();?></h2>
                    <p><strong><?php the_author(); ?></strong><br/>
                        <?php echo get_the_date();?>
                    </p>
                </div>

            </div>

            <div class="row">
                <div class="col-md-8">
               
                    <?php 
                        if(has_post_thumbnail()){
                            $thumbnail_url = get_the_post_thumbnail_url(null, "large");
                            printf('<a href="%s" data-featherlight="image">', $thumbnail_url);
                                the_post_thumbnail("large", "class='img-fluid'");
                            echo "</a>";    
                        }
                     ?>  
                   <?php  the_content();
                   wp_link_pages();
/*
                        next_post_link();
                        echo "<br/>";
                        previous_post_link();*/

                    ?>
                </div>
                <div class="col-md-4">
                    <?php
                        if(is_active_sidebar('sidebar-1')){
                            dynamic_sidebar('sidebar-1');
                        }
                    ?>
                </div>

            </div>
             <?php if(comments_open()):?> 
                <div class="col-md-10 offset-md-1">
                        <?php comments_template(); ?> 
                </div>
            <?php endif; ?>
       </div>
    </div>
<?php endwhile; ?>
    <div class="pagination">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="pagination-text">
                        <?php the_posts_pagination(
                            array(
                                'prev_text' => '< Prev Text',
                                'next_text' => 'Next Text >',

                            ));?>
                    </div>
                </div>
            </div>
        </div>
    </div>


</div>
<?php get_footer(); ?>