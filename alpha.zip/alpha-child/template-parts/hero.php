<div class="header page-header">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
            	 <div class="header_logo">
                    <?php the_custom_logo(); ?>
                </div>
                <h3 class="tagline"><?php bloginfo('description');?></h3>
                <a href="<?php echo site_url();?>"><h1 class="align-self-center display-1 text-center heading">Title<?php bloginfo('title');?></h1></a>
            </div>
        </div>
    </div>
</div>