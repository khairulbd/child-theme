<?php
if(site_url() == 'http://localhost/alpha'){
	define ("VERSION", time());
}else{
	define ("VERSION", wp_get_theme()->get("VERSION"));
}

function alpha_theme(){
	load_theme_textdomain('alpha');
	add_theme_support( 'post-thumbnails' );
	add_theme_support('title-tag');
	$alpha_display_text = array(
		'width'       => '1200',
		'height'       => '600',
		'flex-height'        => true,
        'flex-width'         => true,
		'header-text'       => true,
		'default-text-color' => '#222222',

	);
	add_theme_support('custom-header', $alpha_display_text);
	$alpha_custom_logo_default = array(
		'width' => '100',
		'height' => '100',
	);
	add_theme_support('custom-logo', $alpha_custom_logo_default);
	add_theme_support( 'html5', array( 'search-form' ) );
	register_nav_menu("topmenu", __("top menu", "alpha"));
	register_nav_menu("footermenu", __("footer menu", "alpha"));


//Images Size
	add_image_size("alpha-squre-1", 400, 400, array('left', 'top'));
	add_image_size("alpha-squre-2", 600, 500, array('right', 'center'));
	add_image_size("alpha-squre-3", 400, 400, array('center', 'center'));



}
 add_action('after_setup_theme', 'alpha_theme');




function alphpa_theme_enqueue(){
	wp_enqueue_style('alpha-style', get_stylesheet_uri(), null, VERSION );
	wp_enqueue_style('bootstarp', '//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css');
	//wp_enqueue_style('bootstarps', get_template_directory_uri().'/assets/css/bootstrap.min.css');
	wp_enqueue_style('feather', '//cdn.rawgit.com/noelboss/featherlight/1.7.13/release/featherlight.min.css');

	wp_enqueue_style('alpha-css', get_template_directory_uri() . "assets/css/alpha.css");
	wp_enqueue_script('feather-light', '//cdn.rawgit.com/noelboss/featherlight/1.7.13/release/featherlight.min.js', array('jquery'), '1.7.13', true);
	wp_enqueue_script('main-js', get_template_directory_uri().'/assets/js/main.js', array('jquery'), '1.0', true);

}
add_action('wp_enqueue_scripts', 'alphpa_theme_enqueue');



add_action( 'widgets_init', 'alpha_widget' );
function alpha_widget() {
    register_sidebar( array(
        'name' => __( 'Right Sidebar', 'Alpha' ),
        'id' => 'sidebar-1',
        'description' => __( 'Right side bar here', 'Alpha' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
	'after_widget'  => '</div>',
	'before_title'  => '',
	'after_title'   => '',
    ) );

    register_sidebar( array(
        'name' => __( 'Footer left Sidebar', 'Alpha' ),
        'id' => 'sidebar-2',
        'description' => __( 'Footer Left side bar here', 'Alpha' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
	'after_widget'  => '</div>',
	'before_title'  => '',
	'after_title'   => '',
    ) );

    register_sidebar( array(
        'name' => __( 'Footer Right Sidebar', 'Alpha' ),
        'id' => 'sidebar-3',
        'description' => __( 'Footer Right side bar here', 'Alpha' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
	'after_widget'  => '</div>',
	'before_title'  => '',
	'after_title'   => '',
    ) );


}
function alpha_excerpt($excerpt){
	if(!post_password_required()){
		return $excerpt;
	}else{
		echo get_the_password_form();
	}
}
add_filter("the_excerpt", "alpha_excerpt");

//Menu class
function alpha_menu_class($classes, $item){
	$classes [] = 'list-inline-item';
	return $classes;
}
add_filter("nav_menu_css_class", "alpha_menu_class", 10, 2);

/*function about_feature_image(){
	if(is_page()){
		
		?>
			<style>
				.page-header{background-image: url(<?php echo $thumbnail_url; ?>);}

			</style>

     <?
	}
}
add_action("wp_head", "about_feature_image", 11);*/
if(!function_exists("alpha_about_page_template_banner")){
function alpha_about_page_template_banner(){
    if(is_page()) {
        $alpha_feat_image = get_the_post_thumbnail_url(null,"large");
        ?>
        <style>
            .page-header{
                background-image: url(<?php echo $alpha_feat_image;?>);
            }
        </style>
        <?php
    }
    if(is_front_page()){
    	if(current_theme_supports("custom-header")){

    		?>
			<style>
				
				.header{
					background: url(<?php echo header_image(); ?>);
				}
				.header h3,  a h1.heading{
					color: #<?php echo get_header_textcolor(); ?>;
					<?php 
						if(!display_header_text()){
							echo 'display:none;';
						}

					 ?>
				}


			</style>


    		<?php
    	}

    }
}
add_action("wp_head","alpha_about_page_template_banner",11);

}





function alpha_plist_shortcode($atts){
	extract(shortcode_atts(
		array(
			'title' => 'this is a title',
			'des' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil, laborum.',
			'img' => 'http://localhost/alpha/wp-content/uploads/2019/02/6b376005-3c3b-338a-a136-fda9782614df.jpg'

		),$atts));


$plistss='<div class="mrukup">
	<img src="'.$img.'" alt=""/>
		<div class="m2">
				<h2>'.$title.'</h2>
			'.wpautop($des).'
		</div>

</div>';
return $plistss;

}
add_shortcode("plist_shortcode", "alpha_plist_shortcode");





function post_list_shortcode($atts){
	extract(shortcode_atts(
		array(
			'count'=> 3,
			'type'=> 'post',

		), $atts));

	 $kibr = array(
	 	'post_type'=> $type,
	 	'posts_per_page'=> $count,
	 );

$get_posts = new Wp_Query($kibr);



$plist_markup = '<ul>';
	while($get_posts->have_posts()) : $get_posts->the_post();

		$idd = get_the_ID();

		$plist_markup .= '<li>
			'.get_the_post_thumbnail($idd , 'thumbnail').'
			<h2><?php get_the_title();?></h2>
		</li>';
	endwhile;


$plist_markup .= '</ul>';
wp_reset_query();
return $plist_markup;


}
add_action("post_list", "post_list_shortcode");




function alpha_highlight_search_result($text){
	if(is_search()){
		$pattern = '/('. join('|', explode(' ', get_search_query())).')/i';
		$text    = preg_replace($pattern, '<span class="search-highlight">\0</span>', $text);
	}
	return $text;
}
add_filter('the_content', 'alpha_highlight_search_result');
add_filter('the_excerpt', 'alpha_highlight_search_result');
add_filter('the_title', 'alpha_highlight_search_result');

function alpha_image_resize(){
	return null;

}
add_filter("wp_calculate_image_srcset", "alpha_image_resize");



if(!function_exists('alpha_today_date')){
	function alpha_today_date(){
	echo date('d/m/y');
}

}