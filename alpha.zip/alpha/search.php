<?php get_header();?>
<body <?php body_class();?>>
<?php get_template_part('template-parts/hero');?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="top-menu">
                <?php
                    wp_nav_menu(array(
                        'theme_location' => 'topmenu',
                        'menu_id' => 'topmenucontainer',
                        'menu_class' => 'list-inline text-center',

                    ));
                ?>
            </div>
        </div>
    </div>
</div>
<div class="posts <?php post_class();?>">

    <?php 
        if(!have_posts()){
            ?>
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h3><?php _e('No result Found', 'alpha'); ?></h3>
                    </div>
                </div>
            </div>
            <?php
        }
     ?>

<?php while(have_posts()) : the_post();?>
    <div class="post">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <a href="<?php the_permalink();?>"><h2 class="post-title"><?php the_title(); ?></h2></a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <p>
                        <strong><?php the_author(); ?></strong><br/>
                        <?php echo get_the_date();?>
                    </p>
                    <?php echo get_the_tag_list("<ul class=\"list-unstyled\"><li>" , "<li></li>" ,"</li></ul>");?>
       
                </div>
                <div class="col-md-8">
                    <p>
                    <?php 
                        if(has_post_thumbnail()){
                          echo '<a class="popup" href="#" data-featherlight="image">';  
                             the_post_thumbnail("large", "class='img-fluid'");


                         echo '</a>';
                     }
                    ?>
                   <?php  the_excerpt();   ?>
                    </p>
                        
                 
                </div>
            </div>

        </div>
    </div>
<?php endwhile; ?>
    <div class="pagination">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="pagination-text">
                        <?php the_posts_pagination(
                            array(
                                'prev_text' => '< Prev Text',
                                'next_text' => 'Next Text >',

                            ));?>
                    </div>
                </div>
            </div>
        </div>
    </div>


</div>
<?php get_footer(); ?>